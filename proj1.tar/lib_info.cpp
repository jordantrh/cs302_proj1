#include <iostream>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>

/*

	Jordan Huff(jordantrh) and Austin Tran(atran8utk)
	Link to repo: git@github.com:jordantrh/cs302_proj1.git
	
	Compile command - "make test" or makefile was used, "g++ -o lib_info lib_info.cpp" is also usable
	
    This code reads in entries of artists, their albums, their songs, and various information pertaining to them.
    It is then able to sort the information into maps of structs for artists, albums, and songs; printing out the
    information in the specified format.

	We both worked on this project together mostly by discussing with each
	other on discord and giving each other updates on what was added. The work
	was split evenly as we both discussed the challenges and what should be
	worked on. Communication was very essential during this project.
	
*/

using namespace std;

// datatype for songs, containing the title and the length of the song
struct Song { 
    string title;
    int time;
};

// datatype for albums, containing a map of songs, the name, the length fo the album, and the number of songs
struct Album {
    map <int, Song> songs;
    string name;
    int time;
    int nsongs;
};

// datatype for artists, containing a map of albums, the artist's name, the length of their discography, and the number of songs
struct Artist {
    map <string, Album> albums;
    string name;
    int time;
    int nsongs;
};

// checks if a song exists in an album, inserting it into the struct's map if not
void SongCheck(Artist &artist, Album &album, string title, int time, int track) {
    map<int, Song>::iterator song_it;       // iterator for parsing through song map


    song_it = album.songs.find(track);      
    if (song_it == album.songs.end()) {
        
        // if song doesn't exist, a new song is made
        new Song;
        Song current_song;

        // initializes new song's parameters
        current_song.time = time;
        current_song.title = title;

        // song inserted into map with track number as the key
        album.songs.insert(make_pair(track, current_song));

        // "nsongs" and "time" values updated
        album.nsongs++;
        artist.nsongs++;
        album.time += time;
        artist.time += time;
    }
}

// checks if an album exists in an artist's discography, inserting it into the struct's map if not
void AlbumCheck(Artist &artist, string album, string title, int time, int track){
    map<string, Album>::iterator album_it;          // iterator for parsing through album map

    album_it = artist.albums.find(album);
    if (album_it == artist.albums.end()) {

        // if album doesn't exist, a new album is made
        new Album;
        Album current_album;

        // initializes new album's parameters
        current_album.nsongs = 0;
        current_album.time = 0;

        // album inserted into map with album name as key
        artist.albums.insert(make_pair(album, current_album));

        // "SongCheck" ran to see if current song exists
        SongCheck(artist, artist.albums.at(album), title, time, track);
    }
    else {

        // "SongCheck" ran to see if current song exists
        SongCheck(artist, artist.albums.at(album), title, time, track);
    }
}

// checks if an artist exists in the current map, inserting it into the struct's map if not
void ArtistCheck(map<string, Artist> &artist_map, string artist, string album, string title, int time, int track){
    map<string, Artist>::iterator artist_it;        // iterator for parsing through artist map

    artist_it = artist_map.find(artist);
    if (artist_it == artist_map.end()) {
        
        // if artist doesn't exist, a new artist is made
        new Artist;
        Artist current_artist;
        
        // initializes the artist's parameters
        current_artist.nsongs = 0;
        current_artist.time = 0;

        // artist inserted into map with artist name as key
        artist_map.insert(make_pair(artist, current_artist));

        // "AlbumCheck" ran to see if current album exists
        AlbumCheck(artist_map.at(artist), album, title, time, track);
    }

    else {

        // "AlbumCheck" ran to see if current album exists
        AlbumCheck(artist_map.at(artist), album, title, time, track);
    }
}

// converts string in format "(min):(sec)" to an integer containing the total seconds
int time_conv(string time_string) {
    int time_sec;                   // final result
    int mins, secs;                 // temporary values for minutes and seconds, respectively
    int i=0;                        // iterator
    stringstream ss(time_string);   // stringstream for conversion
    string temp;                    // temporary string

    // grabs "mins" and "secs" from "time_string"
    while(getline(ss, temp, ':'))      // https://stackoverflow.com/questions/10058606/splitting-a-string-by-a-character
    {
        if (i == 0) {
            mins = stoi(temp);
        }

        if (i == 1) {
            secs = stoi(temp);
        }
        i++;
    }

    // calculates total seconds
    time_sec = (mins * 60) + secs;

    return time_sec;
}

int main(int argc,char* argv[])
{
    ifstream inputfile;                 // file for input
    map<string, Artist> artist_map;     // map of every artist read in
    string add_zero;                    // string containing "0" if seconds value is less than 10, used for print formatting
    string line;                        // temporary string for getline
        
    // grabs .txt file from command line
    inputfile.open(argv[1]);

    // loops through every line from "inputfile", grabbing information about every entry
    while(getline(inputfile, line)){
        stringstream ss(line);
        string title, artist, album, genre;     // string values containing information about entry
        int track;                              // track number value
        string time_string;                     // string value for length of song entry, converted to int
        int time_sec;                           // int conversion of "time_string"

        // uses stringstream to grab individual values from entry, seperated by spaces
        ss >> title >> time_string >> artist >> album >> genre >> track;
        
        // replaces underscores with spaces
        replace(title.begin(), title.end(), '_', ' ');
        replace(artist.begin(), artist.end(), '_', ' ');
        replace(album.begin(), album.end(), '_', ' ');
        
        // uses "time_conv" to convert "time_string" to "time_sec"
        time_sec = time_conv(time_string);

        // checks to see if artist exists in map currently, inserting it if need be
            // will also check if the entry's album and song exists, inserting new values if need be
        ArtistCheck(artist_map, artist, album, title, time_sec, track);
    }
    
    // loops through artist map, printing sorted entries in specified format
    for(auto it = artist_map.begin(); it != artist_map.end(); ++it){

        // checks if the total time, when converted to minutes and seconds, has a second value less than 10
            // if so, an extra "0" must be printed before the seconds value for formatting
        if ((it->second.time)%60 < 10) {
            add_zero = "0";
        }
        else {
            add_zero = "";
        }
        
        // prints out artist information
        cout << it->first << ": " << it->second.nsongs << ", "
        << (it->second.time)/60 << ':' 
        << add_zero << (it->second.time)%60 << endl;

        // loops through album map, printing sorted entries in specified format
        for(auto itB = it->second.albums.begin(); itB != it->second.albums.end(); ++itB){
            
            // checks if the total time, when converted to minutes and seconds, has a second value less than 10
                // if so, an extra "0" must be printed before the seconds value for formatting
            if ((itB->second.time)%60 < 10) {
                add_zero = "0";
            }
            else {
                add_zero = "";
            }

            // prints out album information
            cout << "        " << itB->first << ": " << itB->second.nsongs << ", "
            << (itB->second.time)/60 << ':' 
            << add_zero << (itB->second.time)%60 << endl;

            for(auto itC = itB->second.songs.begin(); itC != itB->second.songs.end(); ++itC){
                
                // checks if the total time, when converted to minutes and seconds, has a second value less than 10
                    // if so, an extra "0" must be printed before the seconds value for formatting
                if ((itC->second.time)%60 < 10) {
                    add_zero = "0";
                }
                else {
                    add_zero = "";
                }

                // prints out song information
                cout << "                " << itC->first << ". " << itC->second.title << ": " 
                << (itC->second.time)/60 << ':' 
                << add_zero << (itC->second.time)%60 << endl;
            }
        }
    }
    
    return 0;
}