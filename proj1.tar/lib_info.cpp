#include <iostream>
#include <map>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>

/*

	Jordan Huff(jordantrh) and Austin Tran(atran8utk)
	Link to repo: git@github.com:jordantrh/cs302_proj1.git
	
	Compile command - "make test" or makefile was used
	
	We both worked on this project together mostly by discussing with each
	other on discord and giving each other updates on what was added. The work
	was split evenly as we both discussed the challenges and what should be
	worked on. Communication was very essential during this project.
	
*/

using namespace std;

struct Song { 
    string title;
    int time;  // could also be a string
};

struct Album {
    map <int, Song> songs;
    string name;
    int time;
    int nsongs;  // optional variable but makes it easier
};

struct Artist {
    map <string, Album> albums;
    string name;
    int time;
    int nsongs;
};

void SongCheck(Artist &artist, Album &album, string title, int time, int track) {
    map<int, Song>::iterator song_it;

    song_it = album.songs.find(track);
    if (song_it == album.songs.end()) {
        new Song;
        Song current_song;

        current_song.time = time;
        current_song.title = title;

        album.songs.insert(make_pair(track, current_song));
        album.nsongs++;
        artist.nsongs++;
        album.time += time;
        artist.time += time;
    }
}

void AlbumCheck(Artist &artist, string album, string title, int time, int track){
    map<string, Album>::iterator album_it;

    album_it = artist.albums.find(album);
    if (album_it == artist.albums.end()) {
        new Album;
        Album current_album;

        // initialize album stuff
        current_album.nsongs = 0;
        current_album.time = 0;
        artist.albums.insert(make_pair(album, current_album));
        SongCheck(artist, artist.albums.at(album), title, time, track);
    }
    else {
        SongCheck(artist, artist.albums.at(album), title, time, track);
    }
}

void ArtistCheck(map<string, Artist> &artist_map, string artist, string album, string title, int time, int track){
    map<string, Artist>::iterator artist_it;

    artist_it = artist_map.find(artist);
    if (artist_it == artist_map.end()) {
        new Artist;
        Artist current_artist;
        
        current_artist.nsongs = 0;
        current_artist.time = 0;
        artist_map.insert(make_pair(artist, current_artist));
        AlbumCheck(artist_map.at(artist), album, title, time, track);
    }

    else {
        AlbumCheck(artist_map.at(artist), album, title, time, track);
    }
}

int time_conv(string time_string) {
    int time_sec, mins, secs, i=0;
    stringstream ss(time_string);
    string temp;

    while(getline(ss, temp, ':'))      // https://stackoverflow.com/questions/10058606/splitting-a-string-by-a-character
    {
        if (i == 0) {
            mins = stoi(temp);
        }

        if (i == 1) {
            secs = stoi(temp);
        }
        i++;
    }

    time_sec = (mins * 60) + secs;

    return time_sec;
}

int main(int argc,char* argv[])
{
    ifstream inputfile;
    map<string, Artist> artist_map;
    string add_zero;
    inputfile.open(argv[1]);

    string line;
    while(getline(inputfile, line)){
        stringstream ss(line);
        string title, artist, album, genre;
        int track;
        string time_string;
        int time_sec;
        ss >> title >> time_string >> artist >> album >> genre >> track;
        
        replace(title.begin(), title.end(), '_', ' ');
        replace(artist.begin(), artist.end(), '_', ' ');
        replace(album.begin(), album.end(), '_', ' ');
        
        time_sec = time_conv(time_string);

        ArtistCheck(artist_map, artist, album, title, time_sec, track);
    }
    
    for(auto it = artist_map.begin(); it != artist_map.end(); ++it){

        if ((it->second.time)%60 < 10) {
            add_zero = "0";
        }
        else {
            add_zero = "";
        }
        
        cout << it->first << ": " << it->second.nsongs << ", "
        << (it->second.time)/60 << ':' 
        << add_zero << (it->second.time)%60 << endl;

        for(auto itB = it->second.albums.begin(); itB != it->second.albums.end(); ++itB){

            if ((itB->second.time)%60 < 10) {
                add_zero = "0";
            }
            else {
                add_zero = "";
            }

            cout << "        " << itB->first << ": " << itB->second.nsongs << ", "
            << (itB->second.time)/60 << ':' 
            << add_zero << (itB->second.time)%60 << endl;

            for(auto itC = itB->second.songs.begin(); itC != itB->second.songs.end(); ++itC){

                if ((itC->second.time)%60 < 10) {
                    add_zero = "0";
                }
                else {
                    add_zero = "";
                }

                cout << "                " << itC->first << ". " << itC->second.title << ": " 
                << (itC->second.time)/60 << ':' 
                << add_zero << (itC->second.time)%60 << endl;
            }
        }
    }
    
    return 0;
}